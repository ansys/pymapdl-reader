# Copyright (C) 2021 - 2025 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""
.. _ref_academic_sector_stress_strain:

Stress and Strain from a Cyclic Modal Analysis
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This example shows how to extract strain and stress from a cyclic
modal analysis.

"""

# sphinx_gallery_thumbnail_number = 2
from ansys.mapdl.reader import examples

###############################################################################
# Download the academic modal analysis file
rotor = examples.download_academic_rotor_result()
print(rotor)


###############################################################################
# Plot nodal displacement for result ``(2, 2)``, which corresponds to
# the load step and sub step in fortran indexing.  You could have also
# used the python cumulative index 3.
# rotor._positive_cyclic_dir = True
_ = rotor.plot_nodal_displacement((2, 2), "x", cpos="xy")


###############################################################################
# Extract the nodal elastic strain for the fourth cumulative result.
# Because pymapdl-reader uses zero based indexing, we have to input "3" here.
#
# Depending on the version of ANSYS, MAPDL either does or does not
# write the duplicate sector for a result.  If MAPDL does not write a
# duplicate sector, pymapdl-reader will search for a duplicate mode and use
# that as the duplicate sector in order to be able to expand to the
# full rotor.  Regardless of if there is or isn't a duplicate sector,
# only the master sector will be output.
#
# .. warning::
#     Cyclic results extracted from pymapdl-reader may disagree with MAPDL
#     due to several issues/variations when extracting cyclic results
#     within MAPDL using ``PowerGraphics``.  By default, MAPDL uses
#     ``\EDGE,,,45``, which disables averaging across surface features
#     that exceed 45 degrees, but only writes one value when outputting
#     with ``PRNSOL``.  On the other hand ``pymapdl-reader`` always averages,
#     so you will see differences between MAPDL and ``pymapdl-reader`` in
#     these cases.
nnum, strain = rotor.nodal_elastic_strain(3, full_rotor=True)


###############################################################################
# Plot the nodal elastic strain in the "Z" direction for result ``(5, 2)``.
#
# ``pymapdl-reader`` can plot the displacements while also plotting the
# stress/strain.  Since modal results may or may not be normalized,
# you will have to adjust the ``displacement_factor`` to scale up or
# down the displacement to get a reasonable looking result.  Disable
# plotting the displacement by setting ``show_displacement=False``.
#
# Additionally, you can also save screenshots by setting
# ``screenshot`` to a filename with
# ``screenshot='elastic_strain.png'``.  If you wish to do this without
# manually closing the plotting screen, set ``off_screen=True``.  This
# can help you automate saving screenshots.

_ = rotor.plot_nodal_elastic_strain(
    (5, 2), "Z", show_displacement=True, displacement_factor=0.01
)


###############################################################################
# Plot the nodal elastic stress in the "Z" direction for this rotor.
# Since this is plotting the other pair of modes for the 5th loadstep,
# the displacement of this response is 90 degrees out of phase of
# result ``(5, 2)``
#
# Available stress components are ``['Y', 'Z', 'XY', 'YZ', 'XZ']``
_ = rotor.plot_nodal_stress(
    (5, 1), "Z", show_displacement=True, displacement_factor=0.01
)


###############################################################################
# You can also plot the nodal von mises principal stress.  This plot
# shows the principal stress for result ``(5, 2)``.
#
# Available stress components are ``['S1', 'S2', 'S3', 'SINT', 'SEQV']``.
_ = rotor.plot_principal_nodal_stress(
    (5, 2), "SEQV", show_displacement=True, displacement_factor=0.01
)
